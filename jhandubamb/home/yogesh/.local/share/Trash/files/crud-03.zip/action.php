<?php

if(isset($_POST['submit'])){

    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $email=$_POST['email'];
  
    $dob=$_POST['dob'];
    $nation=$_POST['nation'];
   
    
    $isSubmit=false;
    
    
    $noError=true;
    
    // function validateUserData($name,$email,$phone,$dob){
        if($firstname=='' && strlen($firstname)<3){
            $firstnamemsg="firstname must be 2 charcter";
            $noError=false;
        }
        if($lastname=='' && strlen($lastname)<3){
            $lastnamemsg='last name must be 2 char';
            $noError=false;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL))     {
            $emailmsg= 'invalid email';
            $noError=false;
        }
        if($nation==''){
            $nationmsg='nationality is required';
            $noError=false;
        }
        
        
        if(empty($dob)){ 
            $dobmsg='invalid date';
            $noError=false;
        
        
    
    }

    
    if($noError){
        include 'conn.php';
    }
}

?>