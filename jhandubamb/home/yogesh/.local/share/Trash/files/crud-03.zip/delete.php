<?php 
    include 'conn.php';
    $deleteID=$_GET['id'];
?>
<script>
    alart(are you sure);
</script>
