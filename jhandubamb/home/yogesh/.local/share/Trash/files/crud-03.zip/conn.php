<?php 

$servername='localhost';
$user='root';
$password='Chitahijeeta@0';
$dbname='user';




// Create connection
$conn = mysqli_connect($servername, $user, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$isconnect= 'connected';

?>

<?php include 'data.php' ?>