<?php 
        
    // $query='INSERT INTO register VALUES('.$name.','.$email.','.$dob.','.$phone.')';

    // echo '  updateid'.$updateID;
    echo 'update id'.$_GET['id'];
   
        $insert_query= 'insert into assign3(firstname,lastname,email,nationality,dob) values("'.$firstname.'","'.$lastname.'","'.$email.'","'.$nation.'","'.$dob.'");';
        $query='select id,firstname,lastname,email,nationality,dob from assign3;';



        $delete_query='delete from assign3 where id='.$deleteID.';';
        echo $update_query;
        echo $delete_query;
        echo $deleteID;

        $result=mysqli_query($conn,$query);
        $displayData='';

       
        mysqli_query($conn,$insert_query);

    if(mysqli_num_rows($result) > 0){
       
        while($row = mysqli_fetch_assoc($result)){
            $displayData.= '<tr><td>'.$row['firstname'].'</td><td>'.$row['lastname'].'</td><td>'.$row['email'].'</td><td>'.$row['nationality'].'</td><td>'.$row['dob'].'</td><td><a href="update.php?id='.$row['id'].'" >ed</a><button><a href="delete.php?id='.$row['id'].'">X</a></button>'.'</td> </tr>';
            
        }
      
    }
    else{
        echo 'o result';
    }
    echo $updateacivate;
    if($updateacivate){
        $update_query='update assign3 set firstname="'.$firstname.'",lastname="'.$lastname.'",email="'.$email.'",nationality="'.$nation.'",dob="'.$dob.'" where id='.$_GET['id'].';';

        if(mysqli_query($conn,$update_query)){
            header('location:http://localhost/PHP_DB_Assignment/index.php');
            echo 'hogya';
        }
        else{
            echo 'something wrong';
        }
    }

    if($flag){
        if(mysqli_query($conn,$delete_query)){
            header('location:http://localhost/PHP_DB_Assignment/index.php');
            echo 'deleted';
        }
        else{
            echo 'not deleted';
        }
    }

  
   

?>