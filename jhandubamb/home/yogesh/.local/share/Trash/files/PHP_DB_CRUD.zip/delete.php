<?php 
  
    $deleteID=$_GET['id'];
    $flag=true;
    echo "<script>alert('you want to delete');</script>";
?>

<?php 
include 'conn.php';
?>
