<?php 
include 'action.php';
include 'conn.php';


if(isset($_GET['id'])){
    if(mysqli_query($conn,$delete_query)){
        echo 'deleted';
    }
    else{
        echo 'something wrong';
    }
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form_validation</title>
</head>
<STYLE>
    p{
        color:red;
    }
    header{
        display:flex;
        justify-content:space-between;
        padding:0 3%;
        background-color:black;
        color:aqua;
    }
    footer{
        color:aqua;
        background-color:black;
        padding-bottom:10px;
    }
    input{
        border-color:aqua;
        width:250px;
        margin:10px 10px;
        height:40px;

    }
    button{
        background-color:aqua;
        color:black;
        border-radius:10px;
        border-color:aqua;
    }
    .linediv{
        display:flex;
    }
    p{
        color:red;
    }
    .bgimage{
        margin-top:10%;
        margin-left:30%;
        

    }
    .main{
        display:flex;
    }
    th,td{
        border:1px solid;
    }
</STYLE>
<body>
    <header>
        
        <h1>DEV COMMUNITY</h1>
        <P style='color:aqua;'>LOGIN</P>
    </header>
<div class="main">
     <div>
    <h1> REGISTER PAGE</h1>

<form method='POST'>
    <div class="linediv">
        <div>
            <input type="text" placeholder='FIRST NAME' name='firstname'>
            <p><?php echo $firstnamemsg?></p>
        </div>
        <div>   
            <input type="text" placeholder='LAST NAME' name='lastname'><br>
            <p><?php echo $lastnamemsg;?></p>
        </div>

    </div>


    <div class="linediv">
        <div>
            <input type="text" placeholder='EMAIL' name='email'>
            <p><?php echo $emailmsg;?></p>
        </div>
        <div>
        <input type="date" placeholder='DATE OF BIRTH' name='dob'>
             <p><?php echo $dobmsg;?></p>
            
        </div>
    </div>


    <div class="linediv">
        <div>
        <input type="text" placeholder='NATIONALITY' name="nation"><br>
            <p><?php echo $nationmsg;?></p>
        </div>
</div>
   
    <button type="submit" name='submit'>SUBMIT</button>

</form>
</div>
<div>
    <div class="showData">
           
            <table>
                <tr>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Email</th>
                    <th>Nationality</th>
                    <th>Date of birth</th>
                    <th> Operations</th>
                </tr>
                <?php echo $displayData?>

            </table>
    </div>
</div>
</div>

<footer>
    
</footer>

</body>
</html>